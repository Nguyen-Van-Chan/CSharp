﻿namespace System
{
    internal class MySqlBackup
    {
    }
}