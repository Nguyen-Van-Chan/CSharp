﻿namespace ThuVienUPT
{


    public partial class ThuVienUPTDataSet
    {
    }
}
namespace ThuVienUPT {
    
    
    public partial class ThuVienUPTDataSet {
    }
}
