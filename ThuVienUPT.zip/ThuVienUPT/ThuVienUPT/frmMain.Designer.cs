﻿namespace ThuVienUPT
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ribbonControl1 = new DevExpress.XtraBars.Ribbon.RibbonControl();
            this.barButtonItem3 = new DevExpress.XtraBars.BarButtonItem();
            this.barNguoiDung = new DevExpress.XtraBars.BarButtonItem();
            this.barDangXuat = new DevExpress.XtraBars.BarButtonItem();
            this.barDoiMatKhau = new DevExpress.XtraBars.BarButtonItem();
            this.barSaoLuu = new DevExpress.XtraBars.BarButtonItem();
            this.skinRibbonGalleryBarItem1 = new DevExpress.XtraBars.SkinRibbonGalleryBarItem();
            this.barButtonItem1 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem2 = new DevExpress.XtraBars.BarButtonItem();
            this.barSachTV = new DevExpress.XtraBars.BarButtonItem();
            this.barSachTLV = new DevExpress.XtraBars.BarButtonItem();
            this.barSachDDM = new DevExpress.XtraBars.BarButtonItem();
            this.barSachMNN = new DevExpress.XtraBars.BarButtonItem();
            this.barMuonSach = new DevExpress.XtraBars.BarButtonItem();
            this.barQTTraSach = new DevExpress.XtraBars.BarButtonItem();
            this.barSachNhapVe = new DevExpress.XtraBars.BarButtonItem();
            this.barNhapSach = new DevExpress.XtraBars.BarButtonItem();
            this.barSach = new DevExpress.XtraBars.BarButtonItem();
            this.barTacGia = new DevExpress.XtraBars.BarButtonItem();
            this.barisbn = new DevExpress.XtraBars.BarButtonItem();
            this.barNgonNgu = new DevExpress.XtraBars.BarButtonItem();
            this.barNganSach = new DevExpress.XtraBars.BarButtonItem();
            this.barKeSach = new DevExpress.XtraBars.BarButtonItem();
            this.barSinhVien = new DevExpress.XtraBars.BarButtonItem();
            this.barKhoa = new DevExpress.XtraBars.BarButtonItem();
            this.barLop = new DevExpress.XtraBars.BarButtonItem();
            this.barNhaCungCap = new DevExpress.XtraBars.BarButtonItem();
            this.barPhieuNhap = new DevExpress.XtraBars.BarButtonItem();
            this.barPhieuMuon = new DevExpress.XtraBars.BarButtonItem();
            this.barLinhVuc = new DevExpress.XtraBars.BarButtonItem();
            this.barNhaXuatBan = new DevExpress.XtraBars.BarButtonItem();
            this.barTraSach = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem4 = new DevExpress.XtraBars.BarButtonItem();
            this.barPMQH = new DevExpress.XtraBars.BarButtonItem();
            this.barPMTN = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem5 = new DevExpress.XtraBars.BarButtonItem();
            this.btnAllPM = new DevExpress.XtraBars.BarButtonItem();
            this.ribbonPage1 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup1 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup8 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPage2 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup3 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup4 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup5 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup6 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup7 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPage3 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup9 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup10 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup16 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPage4 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup12 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup14 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonStatusBar = new DevExpress.XtraBars.Ribbon.RibbonStatusBar();
            this.xtraTabControl = new DevExpress.XtraTab.XtraTabControl();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl)).BeginInit();
            this.SuspendLayout();
            // 
            // ribbonControl1
            // 
            this.ribbonControl1.ExpandCollapseItem.Id = 0;
            this.ribbonControl1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.ribbonControl1.ExpandCollapseItem,
            this.barButtonItem3,
            this.barNguoiDung,
            this.barDangXuat,
            this.barDoiMatKhau,
            this.barSaoLuu,
            this.skinRibbonGalleryBarItem1,
            this.barButtonItem1,
            this.barButtonItem2,
            this.barSachTV,
            this.barSachTLV,
            this.barSachDDM,
            this.barSachMNN,
            this.barMuonSach,
            this.barQTTraSach,
            this.barSachNhapVe,
            this.barNhapSach,
            this.barSach,
            this.barTacGia,
            this.barisbn,
            this.barNgonNgu,
            this.barNganSach,
            this.barKeSach,
            this.barSinhVien,
            this.barKhoa,
            this.barLop,
            this.barNhaCungCap,
            this.barPhieuNhap,
            this.barPhieuMuon,
            this.barLinhVuc,
            this.barNhaXuatBan,
            this.barTraSach,
            this.barButtonItem4,
            this.barPMQH,
            this.barPMTN,
            this.barButtonItem5,
            this.btnAllPM});
            this.ribbonControl1.Location = new System.Drawing.Point(0, 0);
            this.ribbonControl1.MaxItemId = 110;
            this.ribbonControl1.Name = "ribbonControl1";
            this.ribbonControl1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.ribbonPage1,
            this.ribbonPage2,
            this.ribbonPage3,
            this.ribbonPage4});
            this.ribbonControl1.Size = new System.Drawing.Size(898, 116);
            this.ribbonControl1.StatusBar = this.ribbonStatusBar;
            this.ribbonControl1.ToolbarLocation = DevExpress.XtraBars.Ribbon.RibbonQuickAccessToolbarLocation.Hidden;
            // 
            // barButtonItem3
            // 
            this.barButtonItem3.Caption = "barButtonItem3";
            this.barButtonItem3.Id = 8;
            this.barButtonItem3.Name = "barButtonItem3";
            // 
            // barNguoiDung
            // 
            this.barNguoiDung.Caption = "Người dùng";
            this.barNguoiDung.Id = 13;
            this.barNguoiDung.LargeWidth = 80;
            this.barNguoiDung.Name = "barNguoiDung";
            // 
            // barDangXuat
            // 
            this.barDangXuat.Caption = "Đăng xuất";
            this.barDangXuat.Id = 14;
            this.barDangXuat.LargeGlyph = global::ThuVienUPT.Properties.Resources.logout64;
            this.barDangXuat.LargeWidth = 80;
            this.barDangXuat.Name = "barDangXuat";
            this.barDangXuat.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barDangXuat_ItemClick);
            // 
            // barDoiMatKhau
            // 
            this.barDoiMatKhau.Caption = "Đổi mật khẩu";
            this.barDoiMatKhau.Id = 15;
            this.barDoiMatKhau.LargeGlyph = global::ThuVienUPT.Properties.Resources.changepass64;
            this.barDoiMatKhau.LargeWidth = 80;
            this.barDoiMatKhau.Name = "barDoiMatKhau";
            this.barDoiMatKhau.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barDoiMatKhau_ItemClick);
            // 
            // barSaoLuu
            // 
            this.barSaoLuu.Caption = "Sao lưu";
            this.barSaoLuu.Id = 16;
            this.barSaoLuu.LargeGlyph = global::ThuVienUPT.Properties.Resources.data_recovery64;
            this.barSaoLuu.LargeWidth = 80;
            this.barSaoLuu.Name = "barSaoLuu";
            this.barSaoLuu.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barSaoLuu_ItemClick);
            // 
            // skinRibbonGalleryBarItem1
            // 
            this.skinRibbonGalleryBarItem1.Caption = "Đổi giao diện";
            this.skinRibbonGalleryBarItem1.Id = 18;
            this.skinRibbonGalleryBarItem1.Name = "skinRibbonGalleryBarItem1";
            // 
            // barButtonItem1
            // 
            this.barButtonItem1.Caption = "Phiếu Nhập";
            this.barButtonItem1.Glyph = global::ThuVienUPT.Properties.Resources.entercoupon;
            this.barButtonItem1.Id = 24;
            this.barButtonItem1.LargeGlyph = global::ThuVienUPT.Properties.Resources.entercoupon;
            this.barButtonItem1.Name = "barButtonItem1";
            // 
            // barButtonItem2
            // 
            this.barButtonItem2.Caption = "Phiếu Mượn";
            this.barButtonItem2.Glyph = global::ThuVienUPT.Properties.Resources.entercoupon;
            this.barButtonItem2.Id = 26;
            this.barButtonItem2.Name = "barButtonItem2";
            // 
            // barSachTV
            // 
            this.barSachTV.Caption = "Toàn Bộ Sách Thư Viện";
            this.barSachTV.Id = 63;
            this.barSachTV.LargeGlyph = global::ThuVienUPT.Properties.Resources.sach64;
            this.barSachTV.Name = "barSachTV";
            this.barSachTV.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barSachTV_ItemClick);
            // 
            // barSachTLV
            // 
            this.barSachTLV.Caption = "Sách Theo Lĩnh Vực";
            this.barSachTLV.Id = 64;
            this.barSachTLV.LargeGlyph = global::ThuVienUPT.Properties.Resources.sach1_64;
            this.barSachTLV.Name = "barSachTLV";
            this.barSachTLV.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barSachTLV_ItemClick);
            // 
            // barSachDDM
            // 
            this.barSachDDM.Caption = "Sách Đang Được Mượn";
            this.barSachDDM.Id = 65;
            this.barSachDDM.LargeGlyph = global::ThuVienUPT.Properties.Resources.sach2_64;
            this.barSachDDM.Name = "barSachDDM";
            this.barSachDDM.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barSachDDM_ItemClick);
            // 
            // barSachMNN
            // 
            this.barSachMNN.Caption = "Sách Mượn Nhiều Nhất";
            this.barSachMNN.Id = 66;
            this.barSachMNN.LargeGlyph = global::ThuVienUPT.Properties.Resources.sach5_64;
            this.barSachMNN.Name = "barSachMNN";
            this.barSachMNN.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barSachMNN_ItemClick);
            // 
            // barMuonSach
            // 
            this.barMuonSach.Caption = "Mượn Sách";
            this.barMuonSach.Id = 67;
            this.barMuonSach.LargeGlyph = global::ThuVienUPT.Properties.Resources.muonsach_64;
            this.barMuonSach.Name = "barMuonSach";
            this.barMuonSach.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barMuonSach_ItemClick);
            // 
            // barQTTraSach
            // 
            this.barQTTraSach.Caption = "Trả Sách";
            this.barQTTraSach.Id = 69;
            this.barQTTraSach.LargeGlyph = global::ThuVienUPT.Properties.Resources.nhapsach_64;
            this.barQTTraSach.Name = "barQTTraSach";
            this.barQTTraSach.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barQTTraSach_ItemClick);
            // 
            // barSachNhapVe
            // 
            this.barSachNhapVe.Caption = "Sách Nhập Về";
            this.barSachNhapVe.Id = 70;
            this.barSachNhapVe.LargeGlyph = global::ThuVienUPT.Properties.Resources.sach6_64;
            this.barSachNhapVe.Name = "barSachNhapVe";
            this.barSachNhapVe.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barSachNhapVe_ItemClick);
            // 
            // barNhapSach
            // 
            this.barNhapSach.Caption = "Nhập Sách";
            this.barNhapSach.Id = 71;
            this.barNhapSach.LargeGlyph = global::ThuVienUPT.Properties.Resources.trasach_64;
            this.barNhapSach.Name = "barNhapSach";
            this.barNhapSach.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barNhapSach_ItemClick);
            // 
            // barSach
            // 
            this.barSach.Caption = "Sách";
            this.barSach.Id = 73;
            this.barSach.LargeGlyph = global::ThuVienUPT.Properties.Resources.books64;
            this.barSach.Name = "barSach";
            this.barSach.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barSach_ItemClick);
            // 
            // barTacGia
            // 
            this.barTacGia.Caption = "Tác giả";
            this.barTacGia.Id = 74;
            this.barTacGia.LargeGlyph = global::ThuVienUPT.Properties.Resources.writer64;
            this.barTacGia.Name = "barTacGia";
            this.barTacGia.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barTacGia_ItemClick);
            // 
            // barisbn
            // 
            this.barisbn.Caption = "Sách-ISBN";
            this.barisbn.Id = 78;
            this.barisbn.LargeGlyph = global::ThuVienUPT.Properties.Resources.barcode64;
            this.barisbn.Name = "barisbn";
            this.barisbn.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barisbn_ItemClick);
            // 
            // barNgonNgu
            // 
            this.barNgonNgu.Caption = "Ngôn ngữ";
            this.barNgonNgu.Id = 79;
            this.barNgonNgu.LargeGlyph = global::ThuVienUPT.Properties.Resources.laguage_64;
            this.barNgonNgu.Name = "barNgonNgu";
            this.barNgonNgu.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barNgonNgu_ItemClick);
            // 
            // barNganSach
            // 
            this.barNganSach.Caption = "Ngăn sách";
            this.barNganSach.Id = 80;
            this.barNganSach.LargeGlyph = global::ThuVienUPT.Properties.Resources.book_compartment64;
            this.barNganSach.Name = "barNganSach";
            this.barNganSach.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barNganSach_ItemClick);
            // 
            // barKeSach
            // 
            this.barKeSach.Caption = "Kệ sách";
            this.barKeSach.Id = 81;
            this.barKeSach.LargeGlyph = global::ThuVienUPT.Properties.Resources.bookshelf64;
            this.barKeSach.Name = "barKeSach";
            this.barKeSach.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barKeSach_ItemClick);
            // 
            // barSinhVien
            // 
            this.barSinhVien.Caption = "Sinh viên";
            this.barSinhVien.Id = 82;
            this.barSinhVien.LargeGlyph = global::ThuVienUPT.Properties.Resources.student64;
            this.barSinhVien.Name = "barSinhVien";
            this.barSinhVien.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barSinhVien_ItemClick);
            // 
            // barKhoa
            // 
            this.barKhoa.Caption = "Khoa";
            this.barKhoa.Id = 83;
            this.barKhoa.LargeGlyph = global::ThuVienUPT.Properties.Resources.faculty64;
            this.barKhoa.Name = "barKhoa";
            this.barKhoa.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barKhoa_ItemClick);
            // 
            // barLop
            // 
            this.barLop.Caption = "Lớp";
            this.barLop.Id = 84;
            this.barLop.LargeGlyph = global::ThuVienUPT.Properties.Resources.class664;
            this.barLop.Name = "barLop";
            this.barLop.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barLop_ItemClick);
            // 
            // barNhaCungCap
            // 
            this.barNhaCungCap.Caption = "Nhà cung cấp";
            this.barNhaCungCap.Id = 85;
            this.barNhaCungCap.LargeGlyph = global::ThuVienUPT.Properties.Resources.supplier64;
            this.barNhaCungCap.Name = "barNhaCungCap";
            this.barNhaCungCap.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barNhaCungCap_ItemClick);
            // 
            // barPhieuNhap
            // 
            this.barPhieuNhap.Caption = "Phiếu Nhập";
            this.barPhieuNhap.Id = 93;
            this.barPhieuNhap.LargeGlyph = global::ThuVienUPT.Properties.Resources.phieunhap2_32;
            this.barPhieuNhap.Name = "barPhieuNhap";
            this.barPhieuNhap.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barPhieuNhap_ItemClick);
            // 
            // barPhieuMuon
            // 
            this.barPhieuMuon.Caption = "Phiếu Mượn";
            this.barPhieuMuon.Id = 94;
            this.barPhieuMuon.LargeGlyph = global::ThuVienUPT.Properties.Resources.phieumuon1_32;
            this.barPhieuMuon.Name = "barPhieuMuon";
            this.barPhieuMuon.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barPhieuMuon_ItemClick);
            // 
            // barLinhVuc
            // 
            this.barLinhVuc.Caption = "Lĩnh vực";
            this.barLinhVuc.Id = 98;
            this.barLinhVuc.LargeGlyph = global::ThuVienUPT.Properties.Resources.category64;
            this.barLinhVuc.Name = "barLinhVuc";
            this.barLinhVuc.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barLinhVuc_ItemClick);
            // 
            // barNhaXuatBan
            // 
            this.barNhaXuatBan.Caption = "Nhà Xuất Bản";
            this.barNhaXuatBan.Id = 99;
            this.barNhaXuatBan.LargeGlyph = global::ThuVienUPT.Properties.Resources.publish64;
            this.barNhaXuatBan.Name = "barNhaXuatBan";
            this.barNhaXuatBan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barNhaXuatBan_ItemClick);
            // 
            // barTraSach
            // 
            this.barTraSach.Caption = "barButtonItem4";
            this.barTraSach.Id = 100;
            this.barTraSach.Name = "barTraSach";
            // 
            // barButtonItem4
            // 
            this.barButtonItem4.Caption = "barButtonItem4";
            this.barButtonItem4.Id = 104;
            this.barButtonItem4.Name = "barButtonItem4";
            // 
            // barPMQH
            // 
            this.barPMQH.Caption = "Phiếu mượn quá hạn";
            this.barPMQH.Id = 106;
            this.barPMQH.LargeGlyph = global::ThuVienUPT.Properties.Resources.PM_64;
            this.barPMQH.Name = "barPMQH";
            this.barPMQH.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barPMQH_ItemClick);
            // 
            // barPMTN
            // 
            this.barPMTN.Caption = "Phiếu mượn theo ngày";
            this.barPMTN.Id = 107;
            this.barPMTN.LargeGlyph = global::ThuVienUPT.Properties.Resources.PM1_64;
            this.barPMTN.Name = "barPMTN";
            this.barPMTN.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barPMTN_ItemClick);
            // 
            // barButtonItem5
            // 
            this.barButtonItem5.Caption = "barButtonItem5";
            this.barButtonItem5.Id = 108;
            this.barButtonItem5.Name = "barButtonItem5";
            // 
            // btnAllPM
            // 
            this.btnAllPM.Caption = "Tất Cả Phiếu Mượn";
            this.btnAllPM.Id = 109;
            this.btnAllPM.LargeGlyph = global::ThuVienUPT.Properties.Resources.Search_icon;
            this.btnAllPM.Name = "btnAllPM";
            this.btnAllPM.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnAllPM_ItemClick);
            // 
            // ribbonPage1
            // 
            this.ribbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup1,
            this.ribbonPageGroup8});
            this.ribbonPage1.Name = "ribbonPage1";
            this.ribbonPage1.Text = "Hệ thống";
            // 
            // ribbonPageGroup1
            // 
            this.ribbonPageGroup1.ItemLinks.Add(this.barDangXuat);
            this.ribbonPageGroup1.ItemLinks.Add(this.barDoiMatKhau);
            this.ribbonPageGroup1.Name = "ribbonPageGroup1";
            this.ribbonPageGroup1.Text = "Người dùng";
            // 
            // ribbonPageGroup8
            // 
            this.ribbonPageGroup8.ItemLinks.Add(this.skinRibbonGalleryBarItem1);
            this.ribbonPageGroup8.Name = "ribbonPageGroup8";
            this.ribbonPageGroup8.Text = "Giao diện";
            // 
            // ribbonPage2
            // 
            this.ribbonPage2.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup3,
            this.ribbonPageGroup4,
            this.ribbonPageGroup5,
            this.ribbonPageGroup6,
            this.ribbonPageGroup7});
            this.ribbonPage2.Name = "ribbonPage2";
            this.ribbonPage2.Text = "Quản Lý Danh Mục";
            // 
            // ribbonPageGroup3
            // 
            this.ribbonPageGroup3.AllowTextClipping = false;
            this.ribbonPageGroup3.ItemLinks.Add(this.barSach);
            this.ribbonPageGroup3.ItemLinks.Add(this.barTacGia);
            this.ribbonPageGroup3.ItemLinks.Add(this.barisbn);
            this.ribbonPageGroup3.ItemLinks.Add(this.barNgonNgu);
            this.ribbonPageGroup3.ItemLinks.Add(this.barLinhVuc);
            this.ribbonPageGroup3.ItemLinks.Add(this.barNhaXuatBan);
            this.ribbonPageGroup3.Name = "ribbonPageGroup3";
            this.ribbonPageGroup3.Text = "Quản Lý Sách";
            // 
            // ribbonPageGroup4
            // 
            this.ribbonPageGroup4.ItemLinks.Add(this.barNganSach);
            this.ribbonPageGroup4.ItemLinks.Add(this.barKeSach);
            this.ribbonPageGroup4.Name = "ribbonPageGroup4";
            this.ribbonPageGroup4.Text = "Vị Trí";
            // 
            // ribbonPageGroup5
            // 
            this.ribbonPageGroup5.AllowTextClipping = false;
            this.ribbonPageGroup5.ItemLinks.Add(this.barSinhVien);
            this.ribbonPageGroup5.ItemLinks.Add(this.barKhoa);
            this.ribbonPageGroup5.ItemLinks.Add(this.barLop);
            this.ribbonPageGroup5.Name = "ribbonPageGroup5";
            this.ribbonPageGroup5.Text = "Sinh Viên";
            // 
            // ribbonPageGroup6
            // 
            this.ribbonPageGroup6.AllowTextClipping = false;
            this.ribbonPageGroup6.ItemLinks.Add(this.barNhaCungCap);
            this.ribbonPageGroup6.Name = "ribbonPageGroup6";
            this.ribbonPageGroup6.Text = "Đối Tác UPT";
            // 
            // ribbonPageGroup7
            // 
            this.ribbonPageGroup7.AllowTextClipping = false;
            this.ribbonPageGroup7.ItemLinks.Add(this.barPhieuNhap);
            this.ribbonPageGroup7.ItemLinks.Add(this.barPhieuMuon);
            this.ribbonPageGroup7.Name = "ribbonPageGroup7";
            this.ribbonPageGroup7.Text = "Quản Lý Phiếu Thư Viện";
            // 
            // ribbonPage3
            // 
            this.ribbonPage3.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup9,
            this.ribbonPageGroup10,
            this.ribbonPageGroup16});
            this.ribbonPage3.Name = "ribbonPage3";
            this.ribbonPage3.Text = "Nghiệp vụ";
            // 
            // ribbonPageGroup9
            // 
            this.ribbonPageGroup9.AllowTextClipping = false;
            this.ribbonPageGroup9.ItemLinks.Add(this.barNhapSach);
            this.ribbonPageGroup9.Name = "ribbonPageGroup9";
            this.ribbonPageGroup9.Text = "Nhập Sách Thư Viện";
            // 
            // ribbonPageGroup10
            // 
            this.ribbonPageGroup10.AllowTextClipping = false;
            this.ribbonPageGroup10.ItemLinks.Add(this.barMuonSach);
            this.ribbonPageGroup10.Name = "ribbonPageGroup10";
            this.ribbonPageGroup10.Text = "Quá Trình Mượn Sách";
            // 
            // ribbonPageGroup16
            // 
            this.ribbonPageGroup16.AllowTextClipping = false;
            this.ribbonPageGroup16.ItemLinks.Add(this.barQTTraSach);
            this.ribbonPageGroup16.Name = "ribbonPageGroup16";
            this.ribbonPageGroup16.Text = "Quá Trình Trả Sách";
            // 
            // ribbonPage4
            // 
            this.ribbonPage4.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup12,
            this.ribbonPageGroup14});
            this.ribbonPage4.Name = "ribbonPage4";
            this.ribbonPage4.Text = "Báo cáo";
            // 
            // ribbonPageGroup12
            // 
            this.ribbonPageGroup12.AllowTextClipping = false;
            this.ribbonPageGroup12.ItemLinks.Add(this.barSachTV);
            this.ribbonPageGroup12.ItemLinks.Add(this.barSachDDM);
            this.ribbonPageGroup12.ItemLinks.Add(this.barSachMNN);
            this.ribbonPageGroup12.ItemLinks.Add(this.barSachNhapVe);
            this.ribbonPageGroup12.Name = "ribbonPageGroup12";
            this.ribbonPageGroup12.Text = "Thống kê sách";
            // 
            // ribbonPageGroup14
            // 
            this.ribbonPageGroup14.AllowTextClipping = false;
            this.ribbonPageGroup14.ItemLinks.Add(this.btnAllPM, true);
            this.ribbonPageGroup14.Name = "ribbonPageGroup14";
            this.ribbonPageGroup14.Text = "Tìm kiếm";
            // 
            // ribbonStatusBar
            // 
            this.ribbonStatusBar.Location = new System.Drawing.Point(0, 376);
            this.ribbonStatusBar.Name = "ribbonStatusBar";
            this.ribbonStatusBar.Ribbon = this.ribbonControl1;
            this.ribbonStatusBar.Size = new System.Drawing.Size(898, 27);
            // 
            // xtraTabControl
            // 
            this.xtraTabControl.ClosePageButtonShowMode = DevExpress.XtraTab.ClosePageButtonShowMode.InAllTabPageHeaders;
            this.xtraTabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraTabControl.Location = new System.Drawing.Point(0, 116);
            this.xtraTabControl.Name = "xtraTabControl";
            this.xtraTabControl.Size = new System.Drawing.Size(898, 260);
            this.xtraTabControl.TabIndex = 6;
            this.xtraTabControl.CloseButtonClick += new System.EventHandler(this.xtraTabControl_CloseButtonClick);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(898, 403);
            this.Controls.Add(this.xtraTabControl);
            this.Controls.Add(this.ribbonStatusBar);
            this.Controls.Add(this.ribbonControl1);
            this.Name = "frmMain";
            this.Text = "Thư viện - Đại học Phan Thiết";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraBars.Ribbon.RibbonControl ribbonControl1;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage1;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup1;
        private DevExpress.XtraBars.Ribbon.RibbonStatusBar ribbonStatusBar;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage3;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage4;
        private DevExpress.XtraBars.BarButtonItem barButtonItem3;
        private DevExpress.XtraBars.BarButtonItem barNguoiDung;
        private DevExpress.XtraBars.BarButtonItem barDangXuat;
        private DevExpress.XtraBars.BarButtonItem barDoiMatKhau;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup8;
        private DevExpress.XtraBars.BarButtonItem barSaoLuu;
        private DevExpress.XtraBars.SkinRibbonGalleryBarItem skinRibbonGalleryBarItem1;
        private DevExpress.XtraTab.XtraTabControl xtraTabControl;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup9;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup10;
        private DevExpress.XtraBars.BarButtonItem barButtonItem1;
        private DevExpress.XtraBars.BarButtonItem barButtonItem2;
        private DevExpress.XtraBars.BarButtonItem barSachTV;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup12;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup14;
        private DevExpress.XtraBars.BarButtonItem barSachTLV;
        private DevExpress.XtraBars.BarButtonItem barSachDDM;
        private DevExpress.XtraBars.BarButtonItem barSachMNN;
        private DevExpress.XtraBars.BarButtonItem barMuonSach;
        private DevExpress.XtraBars.BarButtonItem barQTTraSach;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup16;
        private DevExpress.XtraBars.BarButtonItem barSachNhapVe;
        private DevExpress.XtraBars.BarButtonItem barNhapSach;
        private DevExpress.XtraBars.BarButtonItem barSach;
        private DevExpress.XtraBars.BarButtonItem barTacGia;
        private DevExpress.XtraBars.BarButtonItem barisbn;
        private DevExpress.XtraBars.BarButtonItem barNgonNgu;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage2;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup3;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup4;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup5;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup6;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup7;
        private DevExpress.XtraBars.BarButtonItem barNganSach;
        private DevExpress.XtraBars.BarButtonItem barKeSach;
        private DevExpress.XtraBars.BarButtonItem barSinhVien;
        private DevExpress.XtraBars.BarButtonItem barKhoa;
        private DevExpress.XtraBars.BarButtonItem barLop;
        private DevExpress.XtraBars.BarButtonItem barNhaCungCap;
        private DevExpress.XtraBars.BarButtonItem barPhieuNhap;
        private DevExpress.XtraBars.BarButtonItem barPhieuMuon;
        private DevExpress.XtraBars.BarButtonItem barLinhVuc;
        private DevExpress.XtraBars.BarButtonItem barNhaXuatBan;
        private DevExpress.XtraBars.BarButtonItem barTraSach;
        private DevExpress.XtraBars.BarButtonItem barButtonItem4;
        private DevExpress.XtraBars.BarButtonItem barPMQH;
        private DevExpress.XtraBars.BarButtonItem barPMTN;
        private DevExpress.XtraBars.BarButtonItem barButtonItem5;
        private DevExpress.XtraBars.BarButtonItem btnAllPM;
    }
}

